import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-truck-list',
  templateUrl: './truck-list.component.html',
  styleUrls: ['./truck-list.component.css']
})
export class TruckListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
